package com.cg.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.sql.DataSource;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Repository;

import com.cg.beans.CarDTO;
import com.cg.dao.CarDAO;
import com.cg.util.JDBCDaoException;

//TODO 1 Import appropriate classes based on following TODOs
//PLEASE UPDATE THIS IMPLEMENTATION (REFER TODOS)
/**
 * 
 * This is a JDBCCarDAO class
 * 
 * @see java.lang.Object
 * @author Abhishek
 * 
 *
 */

// TODO 2 Implement appropriate Interface
@Repository
public class JDBCCarDAO implements CarDAO {
	// TODO 3 Declare a local variable datasource of type DataSource follow
	// encapsulation principle
	private DataSource dataSource;
	
	 /*@Autowired
	 ServletContext context;*/ 
	 
	 private ServletContext context;
	 
	 /*@Autowired
	 JDBCCarDAO repository;*/



/*	 public void setServletContext(ServletContext servletContext) {
		 //JDBCCarDAO repository;
		 
	      this.context = servletContext;
	      if(this.context!=null)
	    	  System.out.println("context not null...");
	    //  repository = ((BeanFactory) context).getBean("repo",JDBCCarDAO.class);
	   
			if(null!=repository){
			System.out.println("inside setServletContext...");
			}
	      List<CarDTO> lts = new ArrayList<>();
	      lts = repository.findAll();	
	      
	 }*/
	 

	public DataSource getDataSource(){
		return dataSource;
	}
	public void setDataSource(DataSource dataSource) {
		System.out.println("setting datasource property via injection..");
		this.dataSource=dataSource;
		
		Connection dbconnection;
		try {
			dbconnection = dataSource.getConnection();
			System.out.println(dbconnection + " now available");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
		
	
	
	public JDBCCarDAO() {
		// TODO 4 Initialize the dataSource in TODO 3 using ServiceLocator API
		/*try {
			String dataSourceJndiName = "jdbc/VIMDataSource";
			dataSource = ServiceLocator.getDataSource(dataSourceJndiName);
		} catch (ServiceLocatorException e) {
			e.printStackTrace();
		}*/
		// TODO 5 If any error occur in getting this service then throw
		// ServiceLocatorException
		// with error message as 'Container Service not available'

	}
	
	@Override
	/**
	 * This method is mapped to VIEW_CAR_LIST_ACTION
	 * @return List list of cars 
	 */
	public List<CarDTO> findAll() {
		List<CarDTO> carList = new ArrayList<CarDTO>();

		Connection connection = null;

		String selectQuery = "select * from CAR";

		try {
			try {
				// TODO 9
				// Get a connection using datasource
				connection = dataSource.getConnection();
				// Don't start the JDBC transaction

				// Create a Statement using selectQuery
				Statement selectStatement = connection.createStatement();

				// Invoke appropriate API of JDBC to fire the query
				ResultSet result;
				result = selectStatement.executeQuery(selectQuery);

				// For iteration over the ResultSet populate carList with CarDTO

				while (result.next()) {
					CarDTO carDTO = new CarDTO();
					carDTO.setId(result.getInt(4));
					carDTO.setMake(result.getString(1));
					carDTO.setModel(result.getString(2));
					carDTO.setModelYear(result.getString(3));

					carList.add(carDTO);
				}
			} finally {
				if (connection != null)
					connection.close();
			}
		} catch (SQLException e) {
			throw new JDBCDaoException("SQL error while excecuting query: "
					+ selectQuery, e);
		}

		return carList;
	}


	@Override
	public void create(CarDTO car) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void delete(String[] ids) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void update(CarDTO car) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public CarDTO findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}








	
	
/*
	@Override
	*//**
	 * This method is mapped to ADD_CAR_ACTION
	 * @param car a CarDTO 
	 *//*
	public void create(CarDTO car) {
		// TODO Auto-generated method stub
		Connection connection = null;

		String insertQuery = "insert into Car (MAKE,MODEL,MODEL_YEAR) values(?,?,?)";

		try {
			try {
				// TODO 6
				// Get a connection using datasource
				// Start the JDBC transaction
				// Create a PreparedStatement using insertQuery
				// Set the parameters of the PreparedStatement
				// Invoke appropriate API of JDBC to update and commit the
				// record

			} catch (SQLException e) {
				// e.printStackTrace();

				if (connection != null)
					connection.rollback();
				throw e;
			} finally {
				if (connection != null)
					connection.close();
			}
		} catch (SQLException e) {
			throw new JDBCDaoException(
					"SQL error while excecuting this query: " + insertQuery, e);
		}

	}

	@Override
	*//**
	 * This method is mapped to DELETE_CAR_ACTION
	 * @param ids collection of CAR ids. 
	 *//*
	public void delete(String[] ids) {
		Connection connection = null;
		String deleteQuery = "delete from car where id=?";

		try {
			try {
				// TODO 7
				// Get a connection using datasource
				// Start the JDBC transaction
				// Create a PreparedStatement using deleteQuery
				// Set the parameters of the PreparedStatement
				// Invoke appropriate API of JDBC to update and commit the
				// record

			} catch (SQLException e) {
				if (connection != null)
					connection.rollback();

				throw e;
			} finally {
				if (connection != null)
					connection.close();
			}
		} catch (SQLException e) {
			throw new JDBCDaoException("SQL error while excecuting query: "
					+ deleteQuery, e);
		}
	}

	@Override
	*//**
	 * This method is mapped to EDIT_CAR_ACTION
	 * @param car a CarDTO 
	 *//*
	public void update(CarDTO car) {
		// TODO Auto-generated method stub
		String updateQuery = "update car set make=?,model=?,model_year=? where id=?";
		Connection connection = null;

		try {
			try {
				// TODO 8
				// Get a connection using datasource
				// Start the JDBC transaction
				// Create a PreparedStatement using updateQuery
				// Set the parameters of the PreparedStatement
				// Invoke appropriate API of JDBC to update and commit the
				// record

			} catch (SQLException e) {
				if (connection != null)
					connection.rollback();

				throw e;
			} finally {
				if (connection != null)
					connection.close();
			}
		} catch (SQLException e) {
			throw new JDBCDaoException("SQL error while excecuting query: "
					+ updateQuery, e);
		}
	}


	@Override
	*//**
	 * This method is utility method for finding car by id.
	 * @param id id of the car to be searched
	 * @return  CarDTO A CarDTO
	 *//*
	public CarDTO findById(int id) {
		// TODO Auto-generated method stub
		String selectQuery = "select * from CAR where id=?";
		CarDTO car = new CarDTO();
		Connection connection = null;

		try {
			try {
				connection = dataSource.getConnection();
				connection.setAutoCommit(true);
				PreparedStatement selectStatement = connection
						.prepareStatement(selectQuery);
				selectStatement.setInt(1, id);
				ResultSet result = selectStatement.executeQuery();
				result.next();

				car.setId(result.getInt("id"));
				car.setMake(result.getString("make"));
				car.setModel(result.getString("model"));
				car.setModelYear(result.getString("MODEL_YEAR"));
			} finally {
				if (connection != null)
					connection.close();
			}
		} catch (SQLException e) {
			throw new JDBCDaoException("SQL error while excecuting query: "
					+ selectQuery, e);
		}

		return car;
	}
*/
}
