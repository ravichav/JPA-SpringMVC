package com.cg;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.beans.CarDTO;
import com.cg.dao.CarDAO;

@Controller
@RequestMapping("/controller")
public class VIMControllerHelper {
	
	@Autowired
	private CarDAO carDAO;
	@RequestMapping(method=RequestMethod.GET)
	public String getcars(ModelMap map,@RequestParam("action") String action){
		
		if(action.equals("viewCarList")){

		List<CarDTO> cars = carDAO.findAll();
		map.addAttribute("carList",cars);
		return "carList";
		}
		else if(action.equals("addCar")||action.equals("editCar"))
		{
			return "carForm";
		}
		else{
			return "carList";
		}
	}
	
	@ModelAttribute("car")
	public CarDTO createCar(@RequestParam(value="id",defaultValue="-1") int id){
		System.out.println(carDAO.findById(id));
		
		CarDTO car = carDAO.findById(id) ;
		
		if(car == null){
			car = new CarDTO();
		}
		
		return car;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public String saveCar(@ModelAttribute("car") CarDTO car){
		
		carDAO.update(car);
		
		return "carList";
	}
	

}
