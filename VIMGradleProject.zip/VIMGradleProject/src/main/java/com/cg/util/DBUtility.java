package com.cg.util;

import javax.servlet.ServletContext;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.cg.dao.CarDAO;
import com.cg.dao.impl.JDBCCarDAO;


//TODO 1 Import appropriate packages based on TODOs 2 and 3

//PLEASE UPDATE THIS IMPLEMENTATION (REFER TODOS)
/**
 * 
 * This is a DBUtility class
 * @see java.lang.Object
 * @author Abhishek
 * 
 *
 */
public class DBUtility implements ApplicationContextAware {
	
	//TODO 2 Declare a static reference dao of type CarDAO pointing to JDBCCarDAO instance
	//private static CarDAO carDAO = new JDBCCarDAO();
	
	private static ApplicationContext appContext;

	 /* @Override
		public void setServletContext(ServletContext servletContext) {
			// TODO Auto-generated method stub
	    	System.out.println("setting setServletContext...");
			applicationContext = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
			//JDBCCarDAO repository=applicationContext.getBean("repo",JDBCCarDAO.class);
			//System.out.println(repository);
		}*/
	  
	/**
	 * @return	CarDAO a factory for creating DAO 
	 */
	 //TODO 3 Implement a method getCarDAO which returns dao created in TODO 1
	public static CarDAO getCarDAO() {
	System.out.println("getCarDAO..");
		return appContext.getBean("repo",JDBCCarDAO.class);
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("setting setServletContext...");
		appContext = applicationContext;
	
	}

	/*@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("setting setServletContext...");
		appContext = WebApplicationContextUtils.getRequiredWebApplicationContext(applicationContext);
	
		//JDBCCarDAO repository=applicationContext.getBean("repo",JDBCCarDAO.class);
	}*/


	
	
}
