package com.cg.util;

public class JDBCDaoException extends RuntimeException {
	public JDBCDaoException() {
		// TODO Auto-generated constructor stub
	}

	public JDBCDaoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public JDBCDaoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
